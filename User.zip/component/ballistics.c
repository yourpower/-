/*
  弹道补偿算法。
*/

#include "ballistics.h"

void Ballistics_Init(Ballistics_t *b) { (void)b; }
void Ballistics_Apply(Ballistics_t *b, float bullet_speed) {
  (void)b;
  (void)bullet_speed;
}
void Ballistics_Reset(Ballistics_t *b) { (void)b; }
